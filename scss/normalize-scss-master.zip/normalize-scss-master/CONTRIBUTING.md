# Contributing to normalize-scss

Updates to most CSS rules should be reported to Necolas' upstream [Normalize.css project](http://necolas.github.com/normalize.css/).

Updates to the Sass should be reported in the [Normalize-scss project](https://github.com/JohnAlbin/normalize-scss/).
